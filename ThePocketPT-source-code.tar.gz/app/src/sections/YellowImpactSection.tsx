import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const YellowImpactSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=140%',
          pin: true,
          scrub: 0.6,
          pinSpacing: true,
        },
      });

      // Phase 1 (0-30%): Entrance
      // Yellow background slides in
      scrollTl.fromTo(
        bgRef.current,
        { x: '100vw' },
        { x: 0, ease: 'none' },
        0
      );

      // Image enters from left
      scrollTl.fromTo(
        imageRef.current,
        { x: '-60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.05
      );

      // Headline enters from right
      scrollTl.fromTo(
        headlineRef.current,
        { x: '40vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.05
      );

      // Body enters
      scrollTl.fromTo(
        bodyRef.current,
        { y: '10vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.1
      );

      // CTA enters
      scrollTl.fromTo(
        ctaRef.current,
        { y: '6vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.15
      );

      // Phase 2 (30-70%): Settle

      // Phase 3 (70-100%): Exit
      scrollTl.fromTo(
        headlineRef.current,
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        imageRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        bodyRef.current,
        { y: 0, opacity: 1 },
        { y: '8vh', opacity: 0, ease: 'power2.in' },
        0.72
      );

      scrollTl.fromTo(
        ctaRef.current,
        { y: 0, opacity: 1 },
        { y: '8vh', opacity: 0, ease: 'power2.in' },
        0.74
      );

      // Yellow background exits up
      scrollTl.fromTo(
        bgRef.current,
        { y: 0, opacity: 1 },
        { y: '-20vh', opacity: 0, ease: 'power2.in' },
        0.75
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scrollToPricing = () => {
    const element = document.getElementById('pricing-section');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="section-9"
      className="section-pinned"
      style={{ zIndex: 90 }}
    >
      {/* Yellow Background */}
      <div
        ref={bgRef}
        className="absolute inset-0 bg-[#FFD895]"
        style={{ transform: 'translateX(100vw)' }}
      />

      {/* Left Image Panel */}
      <div
        ref={imageRef}
        className="absolute left-0 top-0 w-[52vw] h-full warm-tint"
      >
        <img
          src="/seated_dumbbells.jpg"
          alt="Get fit from home"
          className="w-full h-full object-cover grayscale"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#FFD895]/20" />
      </div>

      {/* Right Text Panel */}
      <div className="absolute left-[52vw] top-0 w-[48vw] h-full flex flex-col justify-center px-8 lg:px-12">
        <h2
          ref={headlineRef}
          className="font-display font-black text-[#1F1F23] uppercase leading-[0.95] tracking-tight text-4xl sm:text-5xl lg:text-6xl xl:text-7xl mb-8"
        >
          GET FIT FROM HOME
        </h2>

        <p
          ref={bodyRef}
          className="text-[#2B2B30] text-base lg:text-lg max-w-md mb-10 leading-relaxed"
        >
          Coaching, workouts, nutrition—and someone in your corner. All online. All built for real life.
        </p>

        <button
          ref={ctaRef}
          onClick={scrollToPricing}
          className="w-fit px-8 py-4 bg-[#1F1F23] text-[#FFD895] font-semibold rounded-lg hover:scale-105 transition-transform flex items-center gap-2"
        >
          Apply now
          <ArrowRight size={18} />
        </button>
      </div>
    </section>
  );
};

export default YellowImpactSection;
