import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check, ArrowRight, Mail, MessageCircle, Instagram } from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

gsap.registerPlugin(ScrollTrigger);

const pricingPlans = [
  {
    name: '8-Week Kickstart',
    price: '£199',
    description: 'Perfect for getting started and building momentum',
    features: [
      'Custom workout plan',
      'Nutrition guidance',
      'Weekly check-ins',
      'WhatsApp support',
      'Form video reviews',
    ],
    highlighted: false,
  },
  {
    name: '12-Week Transformation',
    price: '£349',
    description: 'Our most popular program for lasting results',
    features: [
      'Everything in Kickstart',
      'Progressive program updates',
      'Bi-weekly video calls',
      'Meal plan templates',
      'Priority support',
      'Lifetime access to materials',
    ],
    highlighted: true,
  },
  {
    name: 'Monthly Coaching',
    price: '£129/mo',
    description: 'Ongoing support for long-term success',
    features: [
      'Monthly program updates',
      'Weekly check-ins',
      'Nutrition tracking',
      'Unlimited WhatsApp',
      'Monthly video call',
      'Cancel anytime',
    ],
    highlighted: false,
  },
];

const faqs = [
  {
    question: 'Do I need a gym membership?',
    answer: 'Not at all. All programs include home workout options with minimal equipment (dumbbells and resistance bands). Gym access is optional.',
  },
  {
    question: 'How much time do I need?',
    answer: 'Most workouts are 30-45 minutes, 3-4 times per week. The program is designed to fit busy schedules.',
  },
  {
    question: 'What if I have dietary restrictions?',
    answer: 'Nutrition plans are fully customized to accommodate allergies, intolerances, and preferences (vegan, vegetarian, etc.).',
  },
  {
    question: 'How quickly will I see results?',
    answer: 'Most clients notice energy and strength improvements within 2 weeks. Visible body changes typically appear by week 4-6 with consistent effort.',
  },
  {
    question: 'Can I switch programs?',
    answer: 'Yes, you can upgrade or change programs at any time. We\'ll prorate any difference.',
  },
];

const PricingSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const pricingRef = useRef<HTMLDivElement>(null);
  const faqRef = useRef<HTMLDivElement>(null);
  const contactRef = useRef<HTMLDivElement>(null);
  const [showDialog, setShowDialog] = useState(false);
  const [dialogMessage, setDialogMessage] = useState('');

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // Pricing cards animation
      const cards = pricingRef.current?.querySelectorAll('.pricing-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { y: 40, opacity: 0, scale: 0.98 },
          {
            y: 0,
            opacity: 1,
            scale: 1,
            duration: 0.6,
            stagger: 0.1,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: pricingRef.current,
              start: 'top 75%',
              end: 'top 55%',
              scrub: 1,
            },
          }
        );
      }

      // FAQ animation
      const faqItems = faqRef.current?.querySelectorAll('.faq-item');
      if (faqItems) {
        gsap.fromTo(
          faqItems,
          { y: 24, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.5,
            stagger: 0.08,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: faqRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }

      // Contact section animation
      gsap.fromTo(
        contactRef.current,
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: contactRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setDialogMessage("Thanks for your interest! We'll be in touch within 24 hours to schedule your free call.");
    setShowDialog(true);
  };

  const handlePlanSelect = (planName: string) => {
    setDialogMessage(`You've selected the ${planName}. We'll contact you shortly to get started!`);
    setShowDialog(true);
  };

  return (
    <section
      ref={sectionRef}
      id="pricing-section"
      className="relative bg-[#353539] py-20 lg:py-32"
      style={{ zIndex: 100 }}
    >
      <div className="max-w-6xl mx-auto px-6 lg:px-12">
        {/* Pricing Header */}
        <div ref={pricingRef} className="text-center mb-16">
          <h2 className="font-display font-black text-[#eaeaea] text-4xl lg:text-5xl mb-4">
            CHOOSE YOUR COACHING
          </h2>
          <p className="text-[#b9b9b9] text-lg max-w-xl mx-auto">
            No hidden fees. No long-term contracts. Just results.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8 mb-24">
          {pricingPlans.map((plan) => (
            <div
              key={plan.name}
              className={`pricing-card rounded-xl p-6 lg:p-8 ${
                plan.highlighted
                  ? 'bg-[#FFD895] text-[#1F1F23] scale-105 shadow-xl'
                  : 'bg-[#3a3a3e] text-[#eaeaea] border border-[#4a4a4e]'
              }`}
            >
              <h3 className="font-display font-bold text-xl mb-2">{plan.name}</h3>
              <div className="font-display font-black text-4xl mb-3">{plan.price}</div>
              <p className={`text-sm mb-6 ${plan.highlighted ? 'text-[#2B2B30]' : 'text-[#b9b9b9]'}`}>
                {plan.description}
              </p>
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3">
                    <Check
                      size={18}
                      className={`mt-0.5 flex-shrink-0 ${
                        plan.highlighted ? 'text-[#1F1F23]' : 'text-[#FFD895]'
                      }`}
                    />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              <button
                onClick={() => handlePlanSelect(plan.name)}
                className={`w-full py-3 rounded-lg font-semibold flex items-center justify-center gap-2 transition-transform hover:scale-105 ${
                  plan.highlighted
                    ? 'bg-[#1F1F23] text-[#FFD895]'
                    : 'bg-[#FFD895] text-[#1F1F23]'
                }`}
              >
                Apply now
                <ArrowRight size={16} />
              </button>
            </div>
          ))}
        </div>

        {/* FAQ Section */}
        <div ref={faqRef} className="mb-24">
          <h2 className="font-display font-black text-[#eaeaea] text-3xl lg:text-4xl text-center mb-10">
            QUESTIONS
          </h2>
          <Accordion type="single" collapsible className="max-w-2xl mx-auto">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="faq-item border-b border-[#4a4a4e]"
              >
                <AccordionTrigger className="text-[#eaeaea] hover:text-[#FFD895] py-5 text-left">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-[#b9b9b9] pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* Contact Section */}
        <div ref={contactRef} className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Contact Info */}
          <div>
            <h2 className="font-display font-black text-[#eaeaea] text-3xl lg:text-4xl mb-4">
              BOOK A FREE CALL
            </h2>
            <p className="text-[#b9b9b9] mb-8">
              Not sure which option fits? Let's talk. No pressure, just honest advice about what's right for you.
            </p>
            <div className="space-y-4">
              <a
                href="mailto:hello@thepocketpt.co.uk"
                className="flex items-center gap-3 text-[#eaeaea] hover:text-[#FFD895] transition-colors"
              >
                <Mail size={20} />
                hello@thepocketpt.co.uk
              </a>
              <a
                href="https://instagram.com/thepocketpt"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-[#eaeaea] hover:text-[#FFD895] transition-colors"
              >
                <Instagram size={20} />
                @thepocketpt
              </a>
              <div className="flex items-center gap-3 text-[#eaeaea]">
                <MessageCircle size={20} />
                WhatsApp: +44 7XXX XXXXXX
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <Input
                type="text"
                placeholder="First name"
                required
                className="bg-[#3a3a3e] border-[#4a4a4e] text-[#eaeaea] placeholder:text-[#6a6a6e] focus:border-[#FFD895] focus:ring-[#FFD895]"
              />
              <Input
                type="text"
                placeholder="Last name"
                required
                className="bg-[#3a3a3e] border-[#4a4a4e] text-[#eaeaea] placeholder:text-[#6a6a6e] focus:border-[#FFD895] focus:ring-[#FFD895]"
              />
            </div>
            <Input
              type="email"
              placeholder="Email address"
              required
              className="bg-[#3a3a3e] border-[#4a4a4e] text-[#eaeaea] placeholder:text-[#6a6a6e] focus:border-[#FFD895] focus:ring-[#FFD895]"
            />
            <Textarea
              placeholder="Tell me about your goals..."
              rows={4}
              className="bg-[#3a3a3e] border-[#4a4a4e] text-[#eaeaea] placeholder:text-[#6a6a6e] focus:border-[#FFD895] focus:ring-[#FFD895] resize-none"
            />
            <button
              type="submit"
              className="btn-primary w-full flex items-center justify-center gap-2"
            >
              Request a call
              <ArrowRight size={18} />
            </button>
          </form>
        </div>

        {/* Footer */}
        <footer className="mt-24 pt-8 border-t border-[#4a4a4e] text-center">
          <p className="text-[#6a6a6e] text-sm">
            © {new Date().getFullYear()} ThePocketPT. All rights reserved.
          </p>
          <div className="flex justify-center gap-6 mt-4">
            <a href="#" className="text-[#6a6a6e] hover:text-[#FFD895] text-sm transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-[#6a6a6e] hover:text-[#FFD895] text-sm transition-colors">
              Terms of Service
            </a>
          </div>
        </footer>
      </div>

      {/* Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="bg-[#3a3a3e] border-[#4a4a4e] text-[#eaeaea]">
          <DialogHeader>
            <DialogTitle className="font-display text-xl">Application Received</DialogTitle>
            <DialogDescription className="text-[#b9b9b9]">
              {dialogMessage}
            </DialogDescription>
          </DialogHeader>
          <button
            onClick={() => setShowDialog(false)}
            className="btn-primary w-full mt-4"
          >
            Got it
          </button>
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default PricingSection;
