import { useEffect, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const HeroSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const photoRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const subheadRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const badgeRef = useRef<HTMLDivElement>(null);
  const yellowWipeRef = useRef<HTMLDivElement>(null);

  // Auto-play entrance animation on mount
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });

      // Photo panel entrance
      tl.fromTo(
        photoRef.current,
        { opacity: 0, x: '-6vw' },
        { opacity: 1, x: 0, duration: 0.9 },
        0
      );

      // Badge entrance
      tl.fromTo(
        badgeRef.current,
        { opacity: 0, scale: 0.96 },
        { opacity: 1, scale: 1, duration: 0.4 },
        0.3
      );

      // Headline words entrance
      const words = headlineRef.current?.querySelectorAll('.headline-word');
      if (words) {
        tl.fromTo(
          words,
          { opacity: 0, y: 24 },
          { opacity: 1, y: 0, duration: 0.8, stagger: 0.04 },
          0.2
        );
      }

      // Subheadline entrance
      tl.fromTo(
        subheadRef.current,
        { opacity: 0, y: 18 },
        { opacity: 1, y: 0, duration: 0.6 },
        0.5
      );

      // CTAs entrance
      tl.fromTo(
        ctaRef.current,
        { opacity: 0, y: 18 },
        { opacity: 1, y: 0, duration: 0.6 },
        0.6
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Scroll-driven exit animation
  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          pinSpacing: true,
          onLeaveBack: () => {
            // Reset all elements when scrolling back to top
            gsap.set([photoRef.current, headlineRef.current, subheadRef.current, ctaRef.current, badgeRef.current], {
              opacity: 1, x: 0, y: 0
            });
            gsap.set(yellowWipeRef.current, { x: '100vw' });
          }
        },
      });

      // Phase 1 (0-30%): Hold - elements stay visible
      // Phase 2 (30-70%): Settle - hold position

      // Phase 3 (70-100%): Exit
      // Headline exits to right
      scrollTl.fromTo(
        headlineRef.current,
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      // Subheadline exits down
      scrollTl.fromTo(
        subheadRef.current,
        { y: 0, opacity: 1 },
        { y: '10vh', opacity: 0, ease: 'power2.in' },
        0.72
      );

      // CTAs exit down
      scrollTl.fromTo(
        ctaRef.current,
        { y: 0, opacity: 1 },
        { y: '8vh', opacity: 0, ease: 'power2.in' },
        0.74
      );

      // Badge exits
      scrollTl.fromTo(
        badgeRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.75
      );

      // Photo panel exits to left
      scrollTl.fromTo(
        photoRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      // Yellow wipe enters from right
      scrollTl.fromTo(
        yellowWipeRef.current,
        { x: '100vw' },
        { x: 0, ease: 'power2.out' },
        0.78
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="section-1"
      className="section-pinned bg-[#353539] z-10"
    >
      {/* Left Photo Panel */}
      <div
        ref={photoRef}
        className="absolute left-0 top-0 w-[52vw] h-full warm-tint"
      >
        <img
          src="/hero_gym_woman.jpg"
          alt="Fitness coaching"
          className="w-full h-full object-cover grayscale"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#353539]/30" />
      </div>

      {/* Right Content Panel */}
      <div className="absolute left-[52vw] top-0 w-[48vw] h-full bg-[#353539] flex flex-col justify-center px-8 lg:px-12">
        {/* Badge */}
        <div
          ref={badgeRef}
          className="mb-6"
        >
          <span className="font-mono text-xs tracking-widest text-[#FFD895] uppercase">
            NEW 8-WEEK PROGRAM
          </span>
          <div className="w-12 h-0.5 bg-[#FFD895] mt-2" />
        </div>

        {/* Headline */}
        <div ref={headlineRef} className="mb-8">
          <h1 className="font-display font-black text-[#eaeaea] uppercase leading-[0.92] tracking-tight">
            <span className="headline-word block text-4xl sm:text-5xl lg:text-6xl xl:text-7xl">ONLINE</span>
            <span className="headline-word block text-4xl sm:text-5xl lg:text-6xl xl:text-7xl">COACHING</span>
            <span className="headline-word block text-4xl sm:text-5xl lg:text-6xl xl:text-7xl">THAT ACTUALLY</span>
            <span className="headline-word block text-4xl sm:text-5xl lg:text-6xl xl:text-7xl accent-yellow">FITS YOUR LIFE</span>
          </h1>
        </div>

        {/* Subheadline */}
        <p
          ref={subheadRef}
          className="text-[#b9b9b9] text-base lg:text-lg max-w-md mb-10 leading-relaxed"
        >
          Fat-loss, strength & confidence—built around your schedule, not the gym's.
        </p>

        {/* CTAs */}
        <div ref={ctaRef} className="flex flex-col sm:flex-row gap-4">
          <button
            onClick={() => scrollToSection('pricing-section')}
            className="btn-primary flex items-center justify-center gap-2"
          >
            Apply for coaching
            <ArrowRight size={18} />
          </button>
          <button
            onClick={() => scrollToSection('section-4')}
            className="text-[#b9b9b9] hover:text-[#FFD895] transition-colors font-medium flex items-center gap-2"
          >
            See how it works
            <ArrowRight size={16} />
          </button>
        </div>
      </div>

      {/* Yellow Wipe Transition */}
      <div
        ref={yellowWipeRef}
        className="absolute inset-0 bg-[#FFD895] z-20 pointer-events-none"
        style={{ transform: 'translateX(100vw)' }}
      />
    </section>
  );
};

export default HeroSection;
