import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navigation from './components/Navigation';
import HeroSection from './sections/HeroSection';
import StatementSection from './sections/StatementSection';
import YellowImpactSection from './sections/YellowImpactSection';
import PricingSection from './sections/PricingSection';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Wait for all sections to mount before setting up global snap
    const timer = setTimeout(() => {
      setupGlobalSnap();
    }, 500);

    return () => {
      clearTimeout(timer);
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  const setupGlobalSnap = () => {
    const pinned = ScrollTrigger.getAll()
      .filter(st => st.vars.pin)
      .sort((a, b) => a.start - b.start);
    
    const maxScroll = ScrollTrigger.maxScroll(window);
    if (!maxScroll || pinned.length === 0) return;

    const pinnedRanges = pinned.map(st => ({
      start: st.start / maxScroll,
      end: (st.end ?? st.start) / maxScroll,
      center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
    }));

    ScrollTrigger.create({
      snap: {
        snapTo: (value: number) => {
          const inPinned = pinnedRanges.some(r => value >= r.start - 0.02 && value <= r.end + 0.02);
          if (!inPinned) return value;
          
          const target = pinnedRanges.reduce((closest, r) =>
            Math.abs(r.center - value) < Math.abs(closest - value) ? r.center : closest,
          pinnedRanges[0]?.center ?? 0);
          
          return target;
        },
        duration: { min: 0.15, max: 0.35 },
        delay: 0,
        ease: "power2.out"
      }
    });
  };

  return (
    <div ref={mainRef} className="relative bg-[#353539]">
      {/* Grain Overlay */}
      <div className="grain-overlay" />
      
      {/* Navigation */}
      <Navigation />
      
      {/* Section 1: Hero */}
      <HeroSection />
      
      {/* Section 2: No More Excuses */}
      <StatementSection
        id="section-2"
        headline="NO MORE EXCUSES"
        body="You don't need more time. You need a plan that works with your life—short sessions, clear guidance, real results."
        cta="Book a free call"
        image="/hoodie_confident.jpg"
        imagePosition="right"
        zIndex={20}
      />
      
      {/* Section 3: Stop Wishing */}
      <StatementSection
        id="section-3"
        headline="STOP WISHING"
        body="The best time to start was yesterday. The next best time is right now."
        cta="Start today"
        image="/cap_gym_woman.jpg"
        imagePosition="left"
        zIndex={30}
      />
      
      {/* Section 4: Start Doing */}
      <StatementSection
        id="section-4"
        headline="START DOING"
        body="You don't need the perfect plan. You need a plan you'll actually follow—short workouts, clear nutrition, daily accountability."
        cta="See the program"
        image="/dumbbells_hold.jpg"
        imagePosition="right"
        zIndex={40}
      />
      
      {/* Section 5: No Gym No Problem */}
      <StatementSection
        id="section-5"
        headline="NO GYM? NO PROBLEM."
        body="Home workouts that actually work. Minimal kit. Maximum progress."
        cta="Train at home"
        image="/seated_dumbbells.jpg"
        imagePosition="left"
        zIndex={50}
      />
      
      {/* Section 6: Your Plan Your Schedule */}
      <StatementSection
        id="section-6"
        headline="YOUR PLAN, YOUR SCHEDULE"
        body="Life changes. Your program adapts. Miss a session? The plan adjusts—so you keep progressing."
        cta="Get your plan"
        image="/standing_dumbbells.jpg"
        imagePosition="right"
        zIndex={60}
      />
      
      {/* Section 7: No BS Nutrition */}
      <StatementSection
        id="section-7"
        headline="NO BS NUTRITION"
        body="No crash diets. No guilt. Just a clear system that fits real life—restaurants, travel, and busy days included."
        cta="See the nutrition system"
        image="/drinking_bottle.jpg"
        imagePosition="left"
        zIndex={70}
      />
      
      {/* Section 8: Real Support */}
      <StatementSection
        id="section-8"
        headline="REAL SUPPORT"
        body="Weekly check-ins, form feedback, and a coach who replies—so you're never stuck guessing."
        cta="Message a coach"
        image="/hoodie_support.jpg"
        imagePosition="right"
        zIndex={80}
      />
      
      {/* Section 9: Yellow Impact */}
      <YellowImpactSection />
      
      {/* Section 10: Pricing & Contact */}
      <PricingSection />
    </div>
  );
}

export default App;
